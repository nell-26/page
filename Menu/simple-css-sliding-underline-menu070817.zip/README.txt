A Pen created at CodePen.io. You can find this one at http://codepen.io/rm/pen/ldhon.

 Updated 4-17-14: padding is now on the anchor instead of the list item so now the hover/click areas are larger and easier to hit. Now uses inline-block instead of floats.