A Pen created at CodePen.io. You can find this one at http://codepen.io/alexerlandsson/pen/ONqdZY.

 This is an extended version of my Pure CSS Slideshow Gallery (http://codepen.io/alexerlandsson/pen/RaZdox) which comes with more and easier customisation and previous/next buttons.