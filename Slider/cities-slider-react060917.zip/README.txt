A Pen created at CodePen.io. You can find this one at https://codepen.io/suez/pen/OjGQza.

 Based on this amazing Dribbble shot by Nicholas - https://dribbble.com/shots/3774469-T-R-A-V-E-L-E-R