A Pen created at CodePen.io. You can find this one at http://codepen.io/suez/pen/grJONP.

 Source of inspiration - https://dribbble.com/shots/2705517-boldybae