/* Fell free to visit my youtube channel 
https://www.youtube.com/channel/UCtVM2RthR4aC6o7dzySmExA
*/